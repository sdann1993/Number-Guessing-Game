package guessme;

/**
 * This class defines a linked list node storing an integer.
 */
public class LLIntegerNode {
	
	private int info;
	private LLIntegerNode link;
	
	public LLIntegerNode(int info) {
		this.info = info;
		link = null;
	}
	
	public void copyNode(LLIntegerNode copy) {
		this.info = copy.getInfo();
		this.link = copy.getLink();
	}
	
	public void setLink(LLIntegerNode link) {
		this.link = link;
	}
	
	public LLIntegerNode getLink() {
		return link;
	}
	
	public void setInfo(int info) {
		this.info = info;
	}
	
	public int getInfo() {
		return info;
	}
	
	
}


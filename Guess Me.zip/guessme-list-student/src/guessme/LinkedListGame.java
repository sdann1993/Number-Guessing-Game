package guessme;


/**
 * A LinkedList-based implementation of the Guess-A-Number game
 */
public class LinkedListGame {
	
	int guess;
	LLIntegerNode priorGuessHead;
	int numGuesses;
	LLIntegerNode candidatesHead;
	LLIntegerNode candidatesTail;
	boolean isOver;
	
	// LinkedListGame constructor method
	public LinkedListGame() {
		guess = 1000;
		priorGuessHead = null;
		numGuesses = 0;
		candidatesHead = new LLIntegerNode(1000);
		candidatesTail = candidatesHead;
		for(int i = 1001; i<=9999; i++) {
			LLIntegerNode node = new LLIntegerNode(i);
			candidatesTail.setLink(node);
			candidatesTail = candidatesTail.getLink();
		}
		isOver = false;
	}
	
	// Resets data members and game state so we can play again
	public void reset() {
		guess = 1000;
		priorGuessHead = null;
		numGuesses = 0;
		candidatesHead = new LLIntegerNode(1000);
		candidatesTail = candidatesHead;
		for(int i = 1001; i<=9999; i++) {
			LLIntegerNode node = new LLIntegerNode(i);
			candidatesTail.setLink(node);
			candidatesTail = candidatesTail.getLink();
		}
		isOver = false;
	}
	
	// Returns true if n is a prior guess; false otherwise.
	public boolean isPriorGuess(int n) {
		LLIntegerNode current = priorGuessHead;
		while(current != null) {
			if(current.getInfo() == n) {
				return true;
			}
			else {
				current = current.getLink();
			}
		}
		return false;
	}
	
	// Returns the number of guesses so far.
	public int numGuesses() {
		return numGuesses;
	}
	
	/**
	 * Returns the number of matches between integers a and b.
	 * You can assume that both are 4-digits long (i.e. between 1000 and 9999).
	 * The return value must be between 0 and 4.
	 * 
	 * A match is the same digit at the same location. For example:
	 *   1234 and 4321 have 0 match;
	 *   1234 and 1114 have 2 matches (1 and 4);
	 *   1000 and 9000 have 3 matches (three 0's).
	 */
	public static int numMatches(int a, int b) {
		int matches = 0;
		for(int i = 0; i<=3; i++) {
		if(a%10 == b%10) {
			matches+=1;
		}
		a = a/10;
		b = b/10;
		}
		return matches;
	}
	
	/**
	 * Returns true if the game is over; false otherwise.
	 * The game is over if the number has been correctly guessed
	 * or if no candidate is left.
	 */
	public boolean isOver() {
		return isOver;
	}
	
	/**
	 * Returns the guess number and adds it to the list of prior guesses.
	 */	
	public int getGuess() {
		numGuesses+=1;
		LLIntegerNode node = new LLIntegerNode(guess);
	    if (priorGuessHead == null) {
	        priorGuessHead = node;
	        return guess;
	    }
	    LLIntegerNode current = priorGuessHead;
	    while (current.getLink() != null) {
	        current = current.getLink();
	    }
	    current.setLink(node);
	    return guess;
	}
		
	
	/**
	 * Updates guess based on the number of matches of the previous guess.
	 * If nmatches is 4, the previous guess is correct and the game is over.
	 * 
	 * Returns true if the update has no error; false if no candidate 
	 * is left (indicating a state of error);
	 */
	
	public boolean updateGuess(int nmatches) {
		LLIntegerNode current = candidatesHead;
		LLIntegerNode newListHead = new LLIntegerNode(0);
		LLIntegerNode newListTail = newListHead;
		if(nmatches == 4) {
			isOver = true;
			return true;
		}
		if(nmatches<4) {
		while(current != null) {
				if(numMatches(guess, current.getInfo()) == nmatches) {
					LLIntegerNode node = new LLIntegerNode(current.getInfo());
					newListTail.setLink(node);
					newListTail = newListTail.getLink();
					}
				current = current.getLink();
		}
		newListHead = newListHead.getLink();
		candidatesHead = newListHead;
		if(candidatesHead != null) {
		guess = candidatesHead.getInfo();
		return true;
		}
		
		}
		return false;
	}

	
	// Returns the head of the prior guesses list.
	// Returns null if there hasn't been any prior guess
	public LLIntegerNode priorGuesses() {
		return priorGuessHead;
	}
	
	/**
	 * Returns the list of prior guesses as a String. 
	 *
	 * Returns an empty string if here hasn't been any prior guess
	 */
	public String priorGuessesString() {
		LLIntegerNode priorGuessTail = priorGuessHead;
		if(priorGuessHead == null) {
		return "";
	}
		if(priorGuessHead.getLink() == null) {
			return Integer.toString(priorGuessHead.getInfo());
		}
		StringBuilder sb = new StringBuilder();
		while(priorGuessTail.getLink() != null) {
			sb.append(priorGuessTail.getInfo()+", ");
			priorGuessTail = priorGuessTail.getLink();
		}
		sb.append(priorGuessTail.getInfo());
		return sb.toString();
	}
	
}
